package com.xzenpress.app;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {
    // XZenPress - Plataforma de Bem-estar Holística
    // Sem publicidade, sem tracking, apenas bem-estar natural
}