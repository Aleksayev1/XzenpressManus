-- Ver TODOS os campos do post "Vida Após a Morte"
-- Verificar se algum campo está NULL e quebrando o mapeamento

SELECT * FROM posts_do_blog WHERE titulo LIKE '%Vida%';
