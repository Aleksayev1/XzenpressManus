INSERT INTO posts_do_blog (titulo, lesma, contente, trecho, autor, categoria, publicado, publicado_em, tempo_leitura) 
VALUES (
  'Vida Após a Morte: Argumentos Científicos Contra o Suicídio',
  'vida-apos-morte-2025',
  'Artigo sobre argumentos científicos contra o suicídio. CVV: 188',
  'Argumentos científicos sobre por que a vida vale a pena',
  'XZenPress',
  'saude-mental',
  true,
  NOW(),
  15
);
