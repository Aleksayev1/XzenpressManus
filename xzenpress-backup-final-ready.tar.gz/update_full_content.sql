-- Template para atualizar o conteúdo completo de cada post
-- Substitua "SEU_CONTEUDO_AQUI" pelo texto completo do artigo

-- 1. Vida Após a Morte
UPDATE posts_do_blog 
SET contente = 'SEU_CONTEUDO_COMPLETO_DO_ARTIGO_AQUI'
WHERE titulo LIKE '%Vida Após a Morte%';

-- 2. Lei 14.831/2024
UPDATE posts_do_blog 
SET contente = 'SEU_CONTEUDO_COMPLETO_DO_ARTIGO_AQUI'
WHERE titulo LIKE '%Lei 14.831%';

-- 3. 5 Pontos de Acupressão
UPDATE posts_do_blog 
SET contente = 'SEU_CONTEUDO_COMPLETO_DO_ARTIGO_AQUI'
WHERE titulo LIKE '%5 Pontos de Acupressão%';

-- 4. Respiração 4-7-8
UPDATE posts_do_blog 
SET contente = 'SEU_CONTEUDO_COMPLETO_DO_ARTIGO_AQUI'
WHERE titulo LIKE '%Respiração 4-7-8%';

-- 5. Cromoterapia
UPDATE posts_do_blog 
SET contente = 'SEU_CONTEUDO_COMPLETO_DO_ARTIGO_AQUI'
WHERE titulo LIKE '%Cromoterapia%';

-- Verificar
SELECT titulo, LENGTH(contente) as tamanho_conteudo
FROM posts_do_blog
ORDER BY published_at DESC;
